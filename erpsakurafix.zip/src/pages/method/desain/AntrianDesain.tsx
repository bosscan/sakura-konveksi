import React from "react";

const AntrianDesain: React.FC = () => (
  <div>
    <h1>List Antrian Desain</h1>
  </div>
);

export default AntrianDesain;
