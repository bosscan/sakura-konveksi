import React from "react";

const RevisiDesain: React.FC = () => (
  <div>
    <h1>List Revisi Desain</h1>
  </div>
);

export default RevisiDesain;
