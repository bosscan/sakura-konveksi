import { Box, Typography } from '@mui/material';
export default function ListRevisiDesain() { return (<Box sx={{ p: 3 }}><Typography variant="h6" fontWeight={700}>List Revisi Desain</Typography><Typography sx={{ mt: 1 }}>Halaman placeholder.</Typography></Box>); }
