import React from "react";

const Produksi: React.FC = () => (
  <div>
    <h1>Tabel Proses - Produksi</h1>
  </div>
);

export default Produksi;
