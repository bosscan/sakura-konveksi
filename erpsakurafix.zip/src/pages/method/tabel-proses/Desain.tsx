import React from "react";

const Desain: React.FC = () => (
  <div>
    <h1>Tabel Proses - Desain</h1>
  </div>
);

export default Desain;
