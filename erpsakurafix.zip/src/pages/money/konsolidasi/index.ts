export { default as Konsolidasi } from './Konsolidasi';
